<?php 

if(isset($_POST['studcomp'])){
require('cons.php');
require('studpanel.php');
	$var1 ='';
    $var1 = $_SESSION['name'];
	 $var2 ='';
     $var2 = $_SESSION['id'] ;
	$department = $_POST['department'];
    $msg = $_POST['msg'];	
    $staff = $_POST['Teachers'];
	$subject = $_POST['subject'];
    $todayDate = date("Y-m-d H:i:s");
    
	
$sql = "INSERT INTO complain (enq_id, subject, enq_msg, staff_id, stud_id, dept, com_date) VALUES(NULL, '$subject',  '$msg', '$staff', '$var2', '$department', '$todayDate')";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "<script>alert('New Complaint sent  Succesfully')</script>";
	echo "<script>window.open('studpanel.php','_self')</script>";
}else{
    
    echo "<script>alert('Sorry an error occurs')</script>";

	//ho "<script>window.open('adminpanel.php','_self')</script>";
}
}


?>