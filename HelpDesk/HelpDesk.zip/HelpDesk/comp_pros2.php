<?php 

if(isset($_POST['studcomp'])){
require('cons.php');
require('appointment.php');
	$var1 ='';
    $var1 = $_SESSION['name'];
	 $var2 ='';
     $var2 = $_SESSION['id'] ;
	$department = $_POST['department'];
    $msg = $_POST['msg'];	
    $staff = $_POST['Teachers'];
    
	
$sql = "INSERT INTO appointment (id, app_msg, stud_id, staff_id, Department_id) VALUES(NULL, '$msg',  '$var2', '$staff','$department' )";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "<script>alert('New Appointment details sent  Succesfully')</script>";
	echo "<script>window.open('studpanel.php','_self')</script>";
}else{
    
    echo "<script>alert('Sorry an error occurs')</script>";

	//ho "<script>window.open('adminpanel.php','_self')</script>";
}
}


?>