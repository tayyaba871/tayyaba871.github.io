<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-folder-open"></i>&nbsp;Search an Incident(s)</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
            <li class="breadcrumb-item"><a href="#">Search an Incident(s)</a></li>
        </ul>
    </div>
    
    <div class="">
        <div class="row">
            <div class="col-md-12 mx-auto">
                <div class="tile">
                    <div class="tile-header">                     
                        <h3 class="tile-title">Search an Incident(s)</h3>                    
                        <form class="form-inline" id="search_form" action="<?php echo e(route("incident.search")); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <label class="control-label">User ID</label>
                            <input class="form-control form-control-sm ml-3" type="text" id="username" name="username" value="<?php echo e($username); ?>" placeholder="User ID">
                            <label class="control-label ml-3">First Name</label>
                            <input class="form-control form-control-sm ml-3" type="text" id="firstname" name="firstname" value="<?php echo e($firstname); ?>" placeholder="First Name">
                            <label class="control-label ml-3">Last Name</label>
                            <input class="form-control form-control-sm ml-3" type="text" id="lastname" name="lastname" value="<?php echo e($lastname); ?>" placeholder="Last Name">                        
                            <label class="control-label ml-3">Phone Number</label>
                            <input class="form-control form-control-sm ml-2" type="text" id="phone" name="phone" value="<?php echo e($phone); ?>" placeholder="Phone Number">
                            <label class="control-label ml-3">Description</label>
                            <input class="form-control form-control-sm ml-2" type="text" id="description" name="description" value="<?php echo e($description); ?>" placeholder="Description" />
                            <label class="control-label ml-3">Urgency</label>
                            <label class="form-check-label ml-3">
                                <input class="form-check-input" type="checkbox" id="urgency_low" name="urgency_low" <?php if($urgency[0]=="on"): ?> checked <?php endif; ?>>Low
                            </label>
                            <label class="form-check-label ml-3">
                                <input class="form-check-input" type="checkbox" id="urgency_high" name="urgency_high" <?php if($urgency[1]=="on"): ?> checked <?php endif; ?>>High
                            </label>
                            <button class="btn btn-primary btn-sm ml-4" type="submit" onclick="search()"><i class="fa fa-fw fa-lg fa-search"></i>Search Now</button>
                            
                        </form>                       
                    </div>
                    <div class="tile-body mt-3">
                        <?php echo csrf_field(); ?>
                        <table class="table table-hover table-bordered text-center" id="documentTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>User ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Phone Number</th>
                                    <th>Urgency</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Comment</th>
                                    <?php if(Auth::user()->role == 'Admin'): ?>
                                        <th>Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(($page_number-1) * 10 + $loop->index+1); ?></td>
                                        <td class="username"><?php if(isset($item->user)): ?> <?php echo e($item->user->name); ?> <?php endif; ?></td>
                                        <td class="firstname"><?php if(isset($item->user)): ?> <?php echo e($item->user->firstname); ?> <?php endif; ?></td>
                                        <td class="lastname"><?php if(isset($item->user)): ?> <?php echo e($item->user->lastname); ?> <?php endif; ?></td>
                                        <td class="phone"><?php if(isset($item->user)): ?> <?php echo e($item->user->phone); ?> <?php endif; ?></td>
                                        <td class="urgency"><?php if($item->urgency == "0"): ?> Low <?php else: ?> High <?php endif; ?></td>
                                        <td class=""><?php echo e($item->description); ?></td>
                                        <td class="status" data-value="<?php echo e($item->status); ?>"><?php if($item->status == 0): ?> Pending <?php elseif($item->status == 1): ?> Work In Process <?php else: ?> Resolve <?php endif; ?></td>
                                        <td class="comment"><?php echo e($item->comment); ?></td>
                                        <?php if(Auth::user()->role == 'Admin'): ?>
                                            <td class="py-2">
                                                <a href="<?php echo e(route('incident.delete', $item->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete" onclick="return confirm('Are you sure?');"><i class="fa fa-trash-o" style="font-size:18px"></i>Delete</a>
                                                <a href="#" class="btn btn-primary btn-sm btn-response" data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Response"><i class="fa fa-edit" style="font-size:18px"></i>Response</a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                            </tbody>
                        </table>
                        <div class="clearfix">
                            <div class="pull-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($incidents->total()); ?></strong> Incidents</p>
                            </div>
                            <div class="pull-right" style="margin: 0;">
                                <?php echo $incidents->links(); ?>

                            </div>
                        </div>
                    </div>                   
                </div>
            </div>            
        </div>
    </div>
    <div class="modal fade" id="responseModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('incident.response')); ?>" id="response_form" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Response</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="incident_id" />
                        <div class="form-group">
                            <label class="control-label">Status</label>
                            <select class="form-control from" name="status" id="status">
                                <option value="0">Pending</option>
                                <option value="1">Work In Process</option>                                
                                <option value="2">Resolve</option>                                
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Comment</label>
                            <textarea class="form-control" name="comment" id="comment"></textarea>
                        </div>

                    </div>
                    
                    <div class="modal-footer">    
                        <button type="submit" id="btn_create" class="btn btn-primary"><i class="fa fa-fw fa-lg fa-check-circle"></i>&nbsp;Save</button>                       
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-times-circle"></i>&nbsp;Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function search(){
            let username = $("#username").val().trim();
            let firstname = $("#firstname").val().trim();
            let lastname = $("#lastname").val().trim();
            let phone = $("#phone").val().trim();
            let description = $("#description").val().trim();
            if (username == '' && firstname == '' && lastname == '' && phone == '' && description == '' && $("#urgency_high").prop('checked') != true && $("#urgency_low").prop('checked') != true) {
                alert("At least one field must be entered.");
                return false;
            }
        }
        $(function(){
            $(".btn-response").click(function(){
                let id = $(this).attr("data-id");
                let status = $(this).parents('tr').find('.status').data('value');
                let comment = $(this).parents('tr').find('.comment').text().trim();
                
                $("#response_form #incident_id").val(id);
                $("#response_form #status").val(status);
                $("#response_form #comment").val(comment);
                $("#responseModal").modal();
            })
        });
    </script>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\BoltonUniversity_Files\BoltonUniversity (09-05-2019)\itsupport\resources\views/search.blade.php */ ?>