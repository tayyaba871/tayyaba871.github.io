<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-database"></i>&nbsp;Knowledge Base</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
            <li class="breadcrumb-item"><a href="#">Knowledge Base</a></li>
        </ul>
    </div>
    <div class="">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="tile">
                    <div class="tile-header">
                        <h3 class="tile-title float-left">Knowledge Base</h3>
                        <div class="float-right">
                            <form class="form-inline" action="<?php echo e(route("kdb.index")); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="app-search">
                                    <input class="form-control" type="search" name="key" value="<?php echo e($key); ?>" style="width:250px;" placeholder="Search(minimum 3 characters)" />
                                    <button class="app-search__button" type="submit"><i class="fa fa-search"></i></button>
                                </div>
                                <?php if(Auth::user()->role == "Admin"): ?>
                                    <a href="<?php echo e(route('kdb.create')); ?>" class="btn btn-primary" id="create_article">Create An Aricle</a>
                                <?php endif; ?>
                            </form>
                            
                        </div>                                             
                    </div>
                    <div class="clearfix"></div>
                    <div class="tile-body mt-3">
                        <h4>List of IT Problems</h4>
                        <table class="table table-hover text-center" id="documentTable">
                            <thead>
                                <tr>
                                    <th width="50">No</th>
                                    <th>Problem</th>
                                    <?php if(Auth::user()->role == 'Admin'): ?>
                                        <th>Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $problems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(($page_number-1) * 10 + $loop->index+1); ?></td>
                                        <td class="problem" align="left"><a href="<?php echo e(route('kdb.solution', $item->id)); ?>"><?php if(isset($item->problem)): ?> <?php echo e($item->kb_number); ?>&nbsp;-&nbsp;<?php echo e($item->problem); ?> <?php endif; ?></a></td>
                                        <?php if(Auth::user()->role == 'Admin'): ?>
                                            <td class="py-2">
                                                <a href="<?php echo e(route('kdb.delete', $item->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete" onclick="return confirm('Are you sure?');"><i class="fa fa-trash-o" style="font-size:18px"></i>Delete</a>
                                                <a href="<?php echo e(route('kdb.edit', $item->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><i class="fa fa-edit" style="font-size:18px"></i>Edit</a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                            </tbody>
                        </table>
                        <div class="clearfix">
                            <div class="pull-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($problems->total()); ?></strong> Problems</p>
                            </div>
                            <div class="pull-right" style="margin: 0;">
                                <?php echo $problems->links(); ?>

                            </div>
                        </div>
                    </div>                   
                </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\helpdesk\BoltonUniversity\BoltonUniversity\itsupport\resources\views/kdb/problem.blade.php */ ?>