<div class="app-sidebar__user"><img class="app-sidebar__user-avatar"src="<?php if(isset(Auth::user()->picture)): ?><?php echo e(asset(Auth::user()->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" alt="User Image">
    <div>
        <p class="app-sidebar__user-name"><?php echo e(Auth::user()->name); ?></p>
        <p class="app-sidebar__user-designation"><?php echo e(Auth::user()->role); ?></p>
    </div>
</div>
<ul class="app-menu">
    <li><a class="app-menu__item <?php if($current_page == 'create'): ?> active <?php endif; ?>" href="<?php echo e(route('home')); ?>"><i class="app-menu__icon fa fa-plus"></i><span class="app-menu__label">Create New Incident</span></a></li>  
    <li><a class="app-menu__item <?php if($current_page == 'search'): ?> active <?php endif; ?>" href="<?php echo e(route('incident.search')); ?>"><i class="app-menu__icon fa fa-search"></i><span class="app-menu__label">Search an Incident(s)</span></a></li>
    <li><a class="app-menu__item <?php if($current_page == 'kdbindex'): ?> active <?php endif; ?>" href="<?php echo e(route('kdb.index')); ?>"><i class="app-menu__icon fa fa-database"></i><span class="app-menu__label">Knowledge Base</span></a></li>
    <?php if(Auth::user()->role == "Admin"): ?>
        <li><a class="app-menu__item <?php if($current_page == 'user'): ?> active <?php endif; ?>" href="<?php echo e(route('user.index')); ?>"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">User Management</span></a></li>       
    <?php endif; ?>
    </ul>
<?php /* C:\xampp\htdocs\BoltonUniversity\itsupport\resources\views/layouts/aside.blade.php */ ?>