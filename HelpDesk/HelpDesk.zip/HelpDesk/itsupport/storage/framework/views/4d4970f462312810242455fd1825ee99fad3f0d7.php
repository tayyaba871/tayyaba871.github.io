<?php $__env->startSection('content'); ?>

<section class="material-half-bg">
    <div class="cover"></div>
</section>
<section class="login-content">
    <a href="<?php echo e(url('/')); ?>" style="text-decoration:none;">
        <div class="logo">
            <h1>Bolton IT Help Desk</h1>
        </div>
    </a>
    <div class="login-box" style="min-height:450px">
        <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
            <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN</h3>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="control-label">USER ID</label>
                <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="UserID" required autofocus>
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label class="control-label">PASSWORD</label>
                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <div class="utility">
                    <div class="animated-checkbox">
                        <label>
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>><span class="label-text">Remember Me</span>
                        </label>
                    </div>

                    <!-- <?php if(Route::has('password.request')): ?>
                        <p class="semibold-text mb-2">
                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>" data-toggle="flip">
                                <?php echo e(__('Forgot Password?')); ?>

                            </a>
                        </p>
                    <?php endif; ?> -->
                </div>
            </div>
            <div class="form-group btn-container">
                <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
            </div>
            <br />
            
        </form>
        
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_script'); ?>
<script type="text/javascript">
    // Login Page Flipbox control
    $('.login-content [data-toggle="flip"]').click(function() {
        $('.login-box').toggleClass('flipped');
        return false;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\helpdesk\corephp\Edusmart\itsupport\resources\views/auth/login.blade.php */ ?>